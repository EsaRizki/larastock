<?php $__env->startSection('title', 'Data Barang'); ?>


<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Barang</li>
              </ol>
            </nav>
            <div class="box box-solid box-primary">
                    <div class="box-header with-border">
                        <h2 class="box-title">Daftar Barang</h2>

                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                                <i class="fa fa-minus"></i></button>
                            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
                                <i class="fa fa-times"></i></button>
                        </div>
                    </div>
                    <div class="box-body">
                  <p>
                    <?php if(Auth::user()->role_id == 1): ?>
                    <a class="btn btn-primary" href="<?php echo e(route('barang.create')); ?>">Tambah</a>
                    <?php endif; ?>
                    
                    <?php if(Auth::user()->role_id == 2): ?>
                    <a class="btn btn-primary" href="#myModal" id="openBtn" data-toggle="modal" data-target="<?php echo e('#' . 'cart' . 'modal'); ?>"><i class="fa fa-shopping-cart"></i> Cart <span class="badge"><?php if(count($badge->where('status',0)) != 0): ?>
                        <?php echo e($badge->where('status', 0)->sum('qty')); ?>

                    <?php endif; ?></span></a>
                        <?php echo $__env->make('transaksi.cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                  </p>
                   <div class="table-responsive">
                        <table id="barang" class="table table-striped table-hover table-bordered responsive dt-responsive display nowrap" cellspacing="0" >
                            <?php if(Auth::user()->role_id == 1): ?>
                                <?php echo $__env->make('barang.tabel_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>

                            <?php if(Auth::user()->role_id == 2): ?>
                                <?php echo $__env->make('barang.tabel_member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>
                        </table>
                    </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready( function () {
            var table = $('#barang').DataTable(

    {
        "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Indonesian.json"
            },
        responsive:false,
     
       dom: 'l Bfrtip',
       buttons: [
       {
            extend: 'print',
            exportOptions: {
                columns: ':visible'
            }
        },
        {
            extend: 'pdf',
            exportOptions: {
                columns: ':visible'
            }
        },
        {
            extend: 'excel',
            exportOptions: {
                columns: ':visible'
            }
        },
            'colvis'
       ],
        columnDefs: [ {
            targets: [2,3,4,6],
            visible: false
        } ],
     
}
);
    });
    </script>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larastock\resources\views/barang/index.blade.php ENDPATH**/ ?>