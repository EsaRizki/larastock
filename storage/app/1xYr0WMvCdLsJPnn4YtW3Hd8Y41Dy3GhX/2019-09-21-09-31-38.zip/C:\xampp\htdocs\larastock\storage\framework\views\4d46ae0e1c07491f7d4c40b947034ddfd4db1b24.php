<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\larastock\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>