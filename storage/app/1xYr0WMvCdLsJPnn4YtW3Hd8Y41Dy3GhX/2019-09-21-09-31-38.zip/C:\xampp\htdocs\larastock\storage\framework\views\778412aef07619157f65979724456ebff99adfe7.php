<form method="POST" action="<?php echo e(route('barang.destroy', $log->id)); ?>">
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('DELETE')); ?>

       <a class="btn btn-primary btn-xs" href="<?php echo e(route('barang.edit', $log->id)); ?>"><span class="glyphicon glyphicon-edit" aria-hidden="true" data-toggle="tooltip" title="Edit"></span></a> <a class="btn btn-primary btn-xs" data-toggle="modal" data-target="<?php echo e('#' . $log->id . 'qr' . '-modal'); ?>"><span class="fa fa-qrcode" aria-hidden="true" data-toggle="tooltip" title="Generate QR Code"></span></a> <a class="btn btn-primary btn-xs" href="<?php echo e(route('harga.jual', $log->id)); ?>"><span class="glyphicon glyphicon-usd" aria-hidden="true" data-toggle="tooltip" title="Set Harga Jual"></span></a>
    <button type="submit" class="btn btn-warning btn-link btn-xs" onclick="return confirm('Apakah anda serius?')"><span class="glyphicon glyphicon-trash" aria-hidden="true" data-toggle="tooltip" title="Hapus"></span> </button>
</form>
<?php /**PATH C:\xampp\htdocs\larastock\resources\views/barang/action.blade.php ENDPATH**/ ?>