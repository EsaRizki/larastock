<?php if(session()->has('flash_notification.message')): ?>
	<div class="container-fluid spark-screen">
				
				<div class="alert alert-<?php echo e(session()->get('flash_notification.level')); ?>">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
					<?php echo session()->get('flash_notification.message'); ?>

				</div>
	</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\larastock\resources\views/layouts/_flash.blade.php ENDPATH**/ ?>