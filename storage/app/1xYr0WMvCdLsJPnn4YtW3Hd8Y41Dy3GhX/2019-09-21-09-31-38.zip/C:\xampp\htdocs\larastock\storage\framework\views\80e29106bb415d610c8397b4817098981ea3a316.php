<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8 col-md-offset-2">
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('harga.jual', $barang)); ?>">Nilai Tiket</a></li>
                <li class="breadcrumb-item active" aria-current="page">Ubah Nilai Tiket</li>
              </ol>
            </nav>
            <div class="box box-solid box-primary">
                    <div class="box-header with-border">
                        <h2 class="box-title">Ubah Nilai Tiket</h2>

                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                                <i class="fa fa-minus"></i></button>
                            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
                                <i class="fa fa-times"></i></button>
                        </div>

                    </div>
                <div class="box-body">
                  <form method="POST" id="myForm" action="<?php echo e(route('harga.update',['barang'=>$barang->id,'area'=>$area->id])); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo e(method_field('PUT')); ?>

                                    <input type="hidden" name="barang_id" value="<?php echo e($barang->id); ?>">
                                    <div class="form-group row">
                                        <label for="nama" class="col-md-offset-2 col-md-2 control-label col-form-label text-md-right"><?php echo e(__('Nama')); ?></label>

                                        <div class="col-md-6">
                                            <input id="nama" type="text" class="form-control <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nama" value="<?php echo e(old('nama', $barang->nama)); ?>" required autocomplete="nama" autofocus disabled="">

                                            <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="area" class="col-md-offset-2 col-md-2 control-label col-form-label text-md-right"><?php echo e(__('Area')); ?></label>

                                        <div class="col-md-6">
                                            <select class="js-example-basic-single form-control area" disabled="" name="area_id">
                                              <option value="<?php echo e($area->id); ?>"><?php echo e($area->nama); ?></option>
                                              
                                                
                                            </select>
                                            <?php if ($errors->has('area')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('area'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="harga" class="col-md-offset-2 col-md-2 control-label col-form-label text-md-right"><?php echo e(__('Harga')); ?></label>

                                        <div class="col-md-6">
                                            <input id="harga" type="number" class="form-control <?php if ($errors->has('harga')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('harga'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="harga" required autocomplete="harga" value="<?php echo e(old('harga', $barang->areas->find($area)->pivot->harga)); ?>" autofocus>

                                            <?php if ($errors->has('harga')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('harga'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                    </div>

                                    <div class="form-group row mb-0">
                                        <div class="col-md-6 col-md-offset-4 offset-md-4">
                                            <button type="submit" class="btn btn-primary">
                                                <?php echo e(__('Simpan')); ?>

                                            </button>
                                        </div>
                                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larastock\resources\views/harga/edit.blade.php ENDPATH**/ ?>