<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8 col-md-offset-2">
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('barang.index')); ?>">Barang</a></li>
                <li class="breadcrumb-item active" aria-current="page">Data Nilai Tiket <?php echo e($barang->nama); ?></li>
              </ol>
            </nav>
            <div class="box box-solid box-primary">
                    <div class="box-header with-border">
                        <h2 class="box-title">Daftar Nilai Tiket <?php echo e($barang->nama); ?></h2>

                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                                <i class="fa fa-minus"></i></button>
                            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
                                <i class="fa fa-times"></i></button>
                        </div>

                    </div>
                <div class="box-body">
                    <p><a class="btn btn-primary" href="<?php echo e(route('harga.create', $barang)); ?>">Tambah</a></p>
                   <div class="table-responsive">
                        <table id="example" class="table table-bordered table-striped display responsive nowrap compact" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Area</th>
                                    <th>Nilai Tiket</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody> 
                                <?php $__currentLoopData = $barang->areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($log->nama); ?></td>
                                    <td><?php echo e($log->pivot->harga); ?></td>
                                    <td><?php echo $__env->make('harga.action', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Area</th>
                                    <th>Nilai Tiket</th>
                                    <th>Action</th>
                                </tr>
                            </tfoot>
                        </table>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
    <script> console.log('Hi!'); </script>
    <script>
    var openFile = function(event) {
    var input = event.target;

    var reader = new FileReader();
    reader.onload = function(){
      var dataURL = reader.result;
      var output = document.getElementById('output');
      output.src = dataURL;
    };
    reader.readAsDataURL(input.files[0]);
  };
</script>

<script>
    var $barang = $('.barang_id');
    var $company2 = $('.area');
    var $location2 = $("#harga");

    $company2.select2().on('change', function() {

        $.ajax({
            url:"/harga/cari/" + $company2.val(), // if you say $(this) here it will refer to the ajax call not $('.company2')
            type:'GET',
            success:function(data) {
                $location2.empty();
                $.each(data, function(value, key) {
                    $location2.append($("#harga").attr("value", value).text(key)); // name refers to the objects value when you do you ->lists('name', 'id') in laravel
                }); //reload the list and select the first option
            }
        });
    }).trigger('change');
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larastock\resources\views/harga/hargaJual.blade.php ENDPATH**/ ?>