<thead>
                                <tr>
                                    <th>Nama</th>
                                    <th>Lokasi</th>
                                    <th>Kondisi</th>
                                    <th>Harga</th>
                                    <th>Keterangan</th>
                                    <th>Sisa</th>
                                    <th>Satuan</th>
                                    <th>Tanggal Input</th>
                                    <th>Tertanda</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody> 
                                <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                
                                    <tr>   
                                        <td>
                                            <?php echo e($log->nama); ?><a href="#myModal" id="openBtn" data-toggle="modal" data-target="<?php echo e('#' . $log->id . 'modal'); ?>"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span></a>
                                            <?php echo $__env->make('barang.detail_barang', ['object' => $log], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </td>
                                        <td><?php echo e($log->lokasi->nama); ?></td>
                                        
                                        <td>
                                        <?php if($log->kondisi == 0): ?>
                                        Baru
                                        <?php elseif($log->kondisi == 1): ?>
                                        Bekas
                                        <?php elseif($log->kondisi == 2): ?>
                                        Rusak
                                        <?php endif; ?>
                                        </td>
                                        <td><a href="<?php echo e(route('harga.jual', $log->id)); ?>"><?php echo e($log->harga); ?></a></td>
                                        <td><?php echo e($log->keterangan); ?></td>
                                        
                                        <td><a href="<?php echo e(route('stok.index', $log->id)); ?>"><?php echo e($log->stoks->sum('qty')); ?></a></td>
                                        <td><?php echo e($log->satuan->nama); ?></td>
                                        <td><?php echo e($log->created_at); ?></td>
                                        <td><?php echo e($log->user->name); ?></td>
                                    
                                        <td><?php echo $__env->make('barang.action', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></td>
                                        <?php echo $__env->make('partials.qrcode', ['object' => $log], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </tr>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Nama</th>
                                    <th>Lokasi</th>
                                    <th>Kondisi</th>
                                    <th>Harga</th>
                                    <th>Keterangan</th>
                                    <th>Sisa</th>
                                    <th>Satuan</th>
                                    <th>Tanggal Input</th>
                                    <th>Tertanda</th>
                                    <th>Action</th>
                                </tr>
                            </tfoot><?php /**PATH C:\xampp\htdocs\larastock\resources\views/barang/tabel_admin.blade.php ENDPATH**/ ?>