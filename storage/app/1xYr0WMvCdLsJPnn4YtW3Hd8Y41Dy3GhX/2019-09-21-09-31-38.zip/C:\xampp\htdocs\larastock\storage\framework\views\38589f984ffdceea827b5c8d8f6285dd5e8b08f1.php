               <form method="POST" action="<?php echo e(route('user.destroy', $log->id)); ?>">
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('DELETE')); ?>

       <a class="btn btn-primary btn-xs" href="<?php echo e(route('user.edit', $log->id)); ?>"><span class="glyphicon glyphicon-edit" aria-hidden="true" data-toggle="tooltip" title="Edit"></span></a>
    <button type="submit" class="btn btn-warning btn-link btn-xs" onclick="return confirm('Apakah anda serius?')"><span class="glyphicon glyphicon-trash" aria-hidden="true" data-toggle="tooltip" title="Hapus"></span> </button>
</form><?php /**PATH C:\xampp\htdocs\larastock\resources\views/user/action.blade.php ENDPATH**/ ?>