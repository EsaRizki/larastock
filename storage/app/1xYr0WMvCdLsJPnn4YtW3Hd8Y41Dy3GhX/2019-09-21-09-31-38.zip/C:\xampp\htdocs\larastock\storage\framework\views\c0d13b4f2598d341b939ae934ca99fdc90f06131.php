<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8 col-md-offset-2">
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('barang.index')); ?>">Barang</a></li>
                <li class="breadcrumb-item active" aria-current="page">Tambah Barang</li>
              </ol>
            </nav>
            <div class="box box-solid box-primary">
                    <div class="box-header with-border">
                        <h2 class="box-title">Tambah Barang</h2>

                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                                <i class="fa fa-minus"></i></button>
                            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
                                <i class="fa fa-times"></i></button>
                        </div>

                    </div>
                <div class="box-body">
                  <form method="POST" action="<?php echo e(route('barang.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('post')); ?>

                        <input type="hidden" name="user_id" value="<?php echo e(Auth::id()); ?>">

                        <div class="form-group row">
                            <label for="nama" class="col-md-offset-2 col-md-2 control-label col-form-label text-md-right"><?php echo e(__('Nama')); ?></label>

                            <div class="col-md-6">
                                <input id="nama" type="text" class="form-control <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nama" value="<?php echo e(old('nama')); ?>" required autocomplete="nama" autofocus>

                                <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="foto" class="col-md-offset-2 col-md-2 control-label col-form-label text-md-right"><?php echo e(__('Foto')); ?></label>

                            <div class="col-md-6">
                                <input id="foto" type="file" class="form-control <?php if ($errors->has('foto')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('foto'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="foto" value="<?php echo e(old('foto')); ?>" autocomplete="foto" required autofocus onchange="openFile(event)">
                                <center>
                                <img id="output" class="img-rounded img-responsive " style="width: 20rem; height: 20rem"></center>
                                <?php if ($errors->has('foto')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('foto'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="kategori" class="col-md-offset-2 col-md-2 control-label col-form-label text-md-right"><?php echo e(__('Kategori')); ?></label>

                            <div class="col-md-6">
                                <select class="js-example-basic-single form-control" name="kategori_id">
                                  <option value="" disabled selected></option>
                                  <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key->id); ?>"><?php echo e($key->nama); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <?php if ($errors->has('kategori')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('kategori'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        
                        <div class="form-group row">
                            <label for="kondisi" class="col-md-offset-2 col-md-2 control-label col-form-label text-md-right"><?php echo e(__('Kondisi')); ?></label>

                            <div class="col-md-6">
                                <select class="js-example-basic-single form-control" name="kondisi">
                                  <option value="" disabled selected></option>
                                    <option value="0">Baru</option>
                                    <option value="1">Bekas</option>
                                    <option value="2">Rusak</option>
                                </select>

                                <?php if ($errors->has('kondisi')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('kondisi'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="gudang" class="col-md-offset-2 col-md-2 control-label col-form-label text-md-right"><?php echo e(__('Gudang')); ?></label>

                            <div class="col-md-6">
                                <select class="js-example-basic-single form-control gudang" name="gudang_id">
                                  <option value="" disabled selected></option>
                                  <?php $__currentLoopData = $gudang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key->id); ?>"><?php echo e($key->nama); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <?php if ($errors->has('gudang')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('gudang'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="lokasi" class="col-md-offset-2 col-md-2 control-label col-form-label text-md-right"><?php echo e(__('Lokasi')); ?></label>

                            <div class="col-md-6">
                                <select class="js-example-basic-single form-control lokasi" name="lokasi_id">
                                  <option value="" disabled selected></option>
                                  <?php $__currentLoopData = $lokasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key->id); ?>"><?php echo e($key->nama); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <?php if ($errors->has('lokasi')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lokasi'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="harga" class="col-md-offset-2 col-md-2 control-label col-form-label text-md-right"><?php echo e(__('Harga')); ?></label>

                            <div class="col-md-6">
                                <input id="harga" type="number" class="form-control <?php if ($errors->has('harga')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('harga'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="harga" value="<?php echo e(old('harga')); ?>" required autocomplete="harga" placeholder="Harga beli" autofocus>

                            <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="exampleCheck1" name="nilaiTiket">
                            <label class="form-check-label" for="exampleCheck1">Atur nilai tiket</label>
                          </div>
                            </div>
                            <div>    
                                <?php if ($errors->has('harga')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('harga'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="jumlah" class="col-md-offset-2 col-md-2 control-label col-form-label text-md-right"><?php echo e(__('Jumlah')); ?></label>

                            <div class="col-md-6">
                                <input id="jumlah" type="number" class="form-control <?php if ($errors->has('jumlah')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('jumlah'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="qty" value="<?php echo e(old('jumlah')); ?>" required autocomplete="jumlah" autofocus>

                                <?php if ($errors->has('jumlah')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('jumlah'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="satuan" class="col-md-offset-2 col-md-2 control-label col-form-label text-md-right"><?php echo e(__('Satuan')); ?></label>

                            <div class="col-md-6">
                                <select class="js-example-basic-single form-control satuan" name="satuan_id">
                                  <option value="" disabled selected></option>
                                  <?php $__currentLoopData = $satuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key->id); ?>"><?php echo e($key->nama); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <?php if ($errors->has('satuan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('satuan'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="Keterangan" class="col-md-offset-2 col-md-2 control-label col-form-label text-md-right"><?php echo e(__('Keterangan')); ?></label>

                            <div class="col-md-6">
                                <textarea name="keterangan" id="keterangan" cols="30" rows="3" class="form-control <?php if ($errors->has('keterangan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('keterangan'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('keterangan')); ?>" autocomplete="keterangan" autofocus></textarea>
                                
                                <?php if ($errors->has('keterangan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('keterangan'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 col-md-offset-4 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Simpan')); ?>

                                </button>
                            </div>
                        </div>
                    </form>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
    <script> console.log('Hi!'); </script>
    <script>
        $(document).ready(function() {
            $("#output").hide();
        });
    </script>
    <script>
    var openFile = function(event) {
    var input = event.target;

    var reader = new FileReader();
    reader.onload = function(){
      var dataURL = reader.result;
      var output = document.getElementById('output');
      output.src = dataURL;
      $("#output").show();
    };
    reader.readAsDataURL(input.files[0]);
  };
</script>
<script>
    var $company2 = $('.gudang');
    var $location2 = $(".lokasi");

    $company2.select2().on('change', function() {
        $.ajax({
            url:"../lokasi/cari/" + $company2.val(), // if you say $(this) here it will refer to the ajax call not $('.company2')
            type:'GET',
            success:function(data) {
                $location2.empty();
                $.each(data, function(value, key) {
                    $location2.append($("<option></option>").attr("value", value).text(key)); // name refers to the objects value when you do you ->lists('name', 'id') in laravel
                });
                $location2.select2(); //reload the list and select the first option
            }
        });
    }).trigger('change');
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larastock\resources\views/barang/create.blade.php ENDPATH**/ ?>