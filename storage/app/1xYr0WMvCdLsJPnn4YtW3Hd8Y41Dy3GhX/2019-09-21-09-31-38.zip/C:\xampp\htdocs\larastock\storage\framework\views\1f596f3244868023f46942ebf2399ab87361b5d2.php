<div id="<?php echo e($log->id . 'modal'); ?>" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Detail <?php echo e($log->nama); ?></h4>
      </div>
      <div class="modal-body">
        <div class="row">
          <center>  
              <?php if(isset($log) && $log->foto): ?>
                <img class="img-rounded img-responsive " style="width: 30rem; height: 30rem" src="<?php echo asset('img/'.$log->foto); ?>">
              <?php else: ?>
                 Foto belum di upload
              <?php endif; ?>
            <div class="row">
                Lokasi : <?php echo e($log->lokasi->nama); ?>

            </div>
            
            <div class="row">
              <?php
                  $transaksi = $log->carts->where('status', 1);
                  $sisa = $log->jumlah - $transaksi->sum('qty'); 
              ?>
                Sisa : <?php echo e($sisa); ?>

            </div>
            <div class="row">
              <a href="<?php echo e(route('barang.transaksi', $log->id)); ?>"><?php echo e($log->carts->where('status', 1)->count()); ?> transaksi</a>
            </div>
          </center>
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\xampp\htdocs\larastock\resources\views/barang/detail_barang.blade.php ENDPATH**/ ?>